package com.meinkonone.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.meinkonone.entity.News;
import com.meinkonone.utils.ConnectToDB;

public class BaseDaoImpl implements BaseDao {

	private String sql;
	private ConnectToDB connectToDB;
	private PreparedStatement statement;
	private ResultSet resultSet;

	public BaseDaoImpl() {
	}

	@Override
	public void insert(News news) {
		sql = "insert into news value(?,?,?,?,?,?,?)";
		connectToDB = new ConnectToDB(sql);
		statement = connectToDB.getPrepareStatement();
		try {
			statement.setString(1, news.getId());
			statement.setString(2, news.getPublisher());
			statement.setString(3, news.getPublish_date());
			statement.setString(4, news.getTitle());
			statement.setString(5, news.getContent());
			statement.setInt(6, news.getSkim_num());
			statement.setString(7, news.getComment());

			int sign = statement.executeUpdate();
			if (sign == 1) {
				System.out.println("�������ݳɹ���");
			} else {
				System.out.println("��������ʧ�ܣ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(String id) {
		sql = "delete from news where id = ?";
		connectToDB = new ConnectToDB(sql);
		statement = connectToDB.getPrepareStatement();
		try {
			statement.setString(1, id);
			int sign = statement.executeUpdate();
			if (sign == 1) {
				System.out.println("ɾ�����ݳɹ���");
			} else {
				System.out.println("ɾ������ʧ�ܣ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(News news) {
		sql = "update news set title = ?, set content = ?, set comment = ? where id =?";
		connectToDB = new ConnectToDB(sql);
		statement = connectToDB.getPrepareStatement();
		try {
			statement.setString(1, news.getTitle());
			statement.setString(2, news.getContent());
			statement.setString(3, news.getComment());
			statement.setString(4, news.getId());
			int sign = statement.executeUpdate();
			if (sign == 1) {
				System.out.println("ɾ�����ݳɹ���");
			} else {
				System.out.println("ɾ������ʧ�ܣ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void select() {
		sql = "select * from news";
		connectToDB = new ConnectToDB(sql);
		statement = connectToDB.getPrepareStatement();
		try {
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				News news = new News();
				news.setId(resultSet.getString("id"));
				news.setPublisher(resultSet.getString("publisher"));
				news.setPublish_date(resultSet.getString("publish_date"));
				news.setTitle(resultSet.getString("title"));
				news.setContent(resultSet.getString("content"));
				news.setSkim_num(resultSet.getInt("skim_num"));
				news.setComment(resultSet.getString("comment"));
				System.out.println(news.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (connectToDB != null) {
				connectToDB.close();
			} else if (resultSet != null) {
				resultSet.close();
			} else if (statement != null) {
				statement.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
