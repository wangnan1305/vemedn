package com.meinkonone.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import com.meinkonone.entity.News;

public class XMLDaoImpl implements BaseDao {

	private SAXBuilder builder = new SAXBuilder();
	private Document doc;
	private Element news_element;
	private List<Element> elements;
	public List<News> newsList = new ArrayList<>();

	@SuppressWarnings("unchecked")
	public XMLDaoImpl() {
		try {
			doc = builder.build(new File("xml/News.xml"));
			news_element = doc.getRootElement();
			elements = news_element.getChildren();
		} catch (JDOMException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void insert(News news) {
		Element element = new Element("news");
		Attribute attribute = new Attribute("id", "0003");
		element.setAttribute(attribute);
		Element publisher = new Element("publisher");
		publisher.setText("����");
		Element publish_date = new Element("publish_date");
		publish_date.setText("2016/5/5");
		Element title = new Element("title");
		title.setText("�ٺٺ�");
		Element content = new Element("content");
		content.setText("������������������");
		Element skim_num = new Element("skim_num");
		skim_num.setText("1004");
		Element comment = new Element("comment");
		comment.setText("������������");

		// �ļ����
		XMLOutputter out = new XMLOutputter();
		try {
			out.output(doc, new FileOutputStream("xml/News.xml"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void delete(String id) {

	}

	@Override
	public void update(News news) {

	}

	@Override
	public void select() {
		for (Element element : elements) {
			News news = new News();
			news.setId(element.getAttributeValue("id"));
			news.setPublisher(element.getChildText("publisher"));
			news.setPublish_date(element.getChildText("publish_date"));
			news.setTitle(element.getChildText("title"));
			news.setContent(element.getChildText("content"));
			news.setSkim_num(Integer.parseInt(element.getChildText("skim_num")));
			news.setComment(element.getChildText("comment"));
			newsList.add(news);
			System.out.println(news.toString());
		}
	}

	@Override
	public void close() {

	}
}
