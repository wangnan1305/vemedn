package com.meinkonone.xml;

import com.meinkonone.dao.BaseDaoImpl;
import com.meinkonone.dao.XMLDaoImpl;

public class MainActivity {

	public static void main(String[] args) {
		XMLDaoImpl xmlDaoImpl = new XMLDaoImpl();
		BaseDaoImpl baseDaoImpl = new BaseDaoImpl();

		xmlDaoImpl.select();
		for (int i = 0; i < xmlDaoImpl.newsList.size(); i++) {
			baseDaoImpl.insert(xmlDaoImpl.newsList.get(i));
		}
	}
}
