package com.meinkonone.entity;

public class News {
	private String id;
	private String publisher;
	private String publish_date;
	private String title;
	private String content;
	private int skim_num;
	private String comment;

	public News() {

	}

	public News(String id, String publisher, String publish_date, String title, String content, int skim_num,
			String comment) {
		super();
		this.id = id;
		this.publisher = publisher;
		this.publish_date = publish_date;
		this.title = title;
		this.content = content;
		this.skim_num = skim_num;
		this.comment = comment;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPublish_date() {
		return publish_date;
	}

	public void setPublish_date(String publish_date) {
		this.publish_date = publish_date;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getSkim_num() {
		return skim_num;
	}

	public void setSkim_num(int skim_num) {
		this.skim_num = skim_num;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "News [id=" + id + ", publisher=" + publisher + ", publish_date=" + publish_date + ", title=" + title
				+ ", content=" + content + ", skim_num=" + skim_num + ", comment=" + comment + "]";
	}
}
