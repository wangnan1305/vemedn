package com.meinkonone.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConnectToDB {

	private static final String DB_URL = "jdbc:mysql://127.0.0.1/xml_ex?characterEncoding=utf8";
	private static final String DB_NAME = "com.mysql.jdbc.Driver";
	private static final String USER = "root";
	private static final String PSD = "";

	private Connection connection;
	private PreparedStatement statement;

	public ConnectToDB(String sql) {
		try {
			Class.forName(DB_NAME);
			connection = DriverManager.getConnection(DB_URL, USER, PSD);
			statement = connection.prepareStatement(sql);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ��ȡPrepareStatement
	 * 
	 * @return
	 */
	public PreparedStatement getPrepareStatement() {
		if (statement != null) {
			return statement;
		}
		return null;
	}

	/**
	 * ������Դ
	 */
	public void close() {
		try {
			if (statement != null) {
				statement.close();
			} else if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
